# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 16:10:43 2018

@author: John
"""

import matplotlib as mpl            # NEED THIS FOR MATPLOTLIB TO WORK WITH ACCRE
mpl.use('Agg')
import matplotlib.pyplot as plt

import numpy as np

t0 = 0
tf = 10
num_tpoints = 100

t = np.linspace(t0, tf, num_tpoints + 1)
x = np.zeros(num_tpoints + 1)

for i in range(0, num_tpoints + 1):
    x[i] = np.exp(-t[i])
    

plt.plot(t, x)
plt.title("Title of plot")
plt.xlabel("x axis label")
plt.ylabel("y axis label")

plt.savefig("myplot.png")     # NEED THIS TO SAVE PLOT AS PICTURE
plt.show()
