# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 15:52:27 2018

@author: John
"""

print("I am a basic python file.")
print("You don't have to include any special libraries to run me.")