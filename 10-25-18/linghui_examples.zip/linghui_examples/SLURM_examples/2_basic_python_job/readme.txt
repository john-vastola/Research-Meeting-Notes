This is an example of a basic python job you can submit to ACCRE.

You can submit basic python jobs without doing anything fancy (like importing modules).
If you want to use special libraries, like the ones included with Anaconda, you need to
add an extra command (that will be covered in the next example). 

Submit this by going to the directory you put it in (using the cd linux command) and typing:
sbatch basic_python_job.slurm

It runs the file basic_python.py

Make sure to change the email in the SLURM file to your email so it tells you when it starts,
and when it ends.