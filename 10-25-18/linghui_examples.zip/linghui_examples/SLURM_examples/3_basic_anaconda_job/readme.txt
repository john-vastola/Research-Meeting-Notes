This is an example of a python job requiring Anaconda libraries that you can submit to ACCRE.

Most libraries we need (like numpy and scipy) are included in Anaconda. To tell ACCRE you need Anaconda libraries,include the following line in your .SLURM file:

module load Anaconda3

Submit this by going to the directory you put it in (using the cd linux command) and typing:
sbatch basic_anaconda_job.slurm

It runs the file basic_anaconda.py

Make sure to change the email in the SLURM file to your email so it tells you when it starts,
and when it ends.