# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 15:52:27 2018

@author: John
"""


import numpy as np

print("I am a python file that needs Anaconda libraries (like numpy).")
print("You need to include a line telling ACCRE to load Anaconda in my .SLURM file.")



size = 10

x = np.zeros(size)

for i in range(0, size):
    x[i] = i**2
    
print(x)