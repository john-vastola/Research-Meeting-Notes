This is an example of a basic job you can submit to ACCRE.

Submit it by going to the directory you put it in (using the cd linux command) and typing:
sbatch basic_job.slurm

All it does is write the words: "This is my first job. Aww yeah!"

Make sure to change the email in the SLURM file to your email so it tells you when it starts,
and when it ends.